tibin2obj - convert a binary block of data into a TI object file that absolutely loads at a fixed address.
tibin2obj <binary file> <object file> <address in hex>

tibin2robj - convert a binary block of data into a TI object file that loads relocatably, and is saved as TIFILES uncompressed for XB
tibin2robj <binary file> <object file>

tiobj2bin - convert an uncompressed TI object file (in windows text file format) into a binary file.
tiobj2bin <object file> <binary file> -raw -block
-Only Absolute data is handled.
-raw will skip the padding and TIFILES and PROGRAM headers, and just write the data
-block will assume that the input object file has no line endings (xas99 does this)

